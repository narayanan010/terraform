console.log('Loading function');

const https = require('https');
const url = require('url');
//const slack_url = 'https://hooks.slack.com/services/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';
const slack_url = process.env.WEBHOOK_URL;
const slack_req_opts = url.parse(slack_url);
slack_req_opts.method = 'POST';
slack_req_opts.headers = {
    'Content-Type': 'application/json'
};

exports.handler = function (event, context) {
    (event.Records || []).forEach(function (rec) {
        if (rec.Sns) {
            var req = https.request(slack_req_opts, function (res) {
                if (res.statusCode === 200) {
                    context.succeed('posted to slack');
                } else {
                    context.fail('status code: ' + res.statusCode);
                }
            });

            req.on('error', function (e) {
                console.log('problem with request: ' + e.message);
                context.fail(e.message);
            });

            var text_msg = JSON.stringify(rec.Sns.Message, null, '  ');
            try {
                var msg_data = [];
                var m_arn ='';
                var m_time='';
                var m_event='';
                msg_data.push('------------ JSON Message -------------------\n');
               // msg_data.push('JSON Message:\n');
                var parsed = JSON.parse(rec.Sns.Message);
                for (var key in parsed) {

                    if (typeof parsed[key] == "object" && parsed[key]) {

                        var subkey = parsed[key];
                        msg_data.push(key + ': ');

                        for (var skey in subkey) {

                            if (typeof subkey[skey] == "object" && subkey[skey]) {
                                var ssubkey = subkey[skey];
                                msg_data.push('->'+skey + ': ');
                                for (var sskey in ssubkey) {

                                    if (typeof ssubkey[sskey] == "object" && ssubkey[sskey]) {
                                        var sssubkey = ssubkey[sskey];
                                        msg_data.push('-->' + sskey + ': ');
                                        for (var ssskey in sssubkey) {

                                            if (typeof sssubkey[ssskey] == "object" && sssubkey[ssskey]) {
                                                var ssssubkey = sssubkey[ssskey];
                                                msg_data.push('--->' + ssskey + ': ');
                                                for (var sssskey in ssssubkey) {
                                                    msg_data.push('---->' + sssskey + ': ' + ssssubkey[sssskey]);
                                                }
                                            } else {
                                                msg_data.push('--->' + ssskey + ': ' + sssubkey[ssskey]);
                                            }

                                        }
                                    } else {
                                        msg_data.push('-->' + sskey + ': ' + ssubkey[sskey]);

                                        if (sskey == 'arn') {
                                            m_arn=ssubkey[sskey];
                                        }

                                    }


                                }
                            } else {
                                msg_data.push('->' + skey + ': ' + subkey[skey]);


                                if (skey == 'eventTime'){
                                    m_time=subkey[skey];
                                }
                                
                                if (skey == 'eventName'){
                                    m_event=subkey[skey];
                                }


                            }
                        }
                    } else {
                        msg_data.push(key + ': ' + parsed[key]);
                    }
                }
                text_msg = msg_data.join('\n');
                console.log('Text Message : <' + text_msg + '>');
                
            } catch (e) {
                console.log(e);
            }
            
            if ( m_event.toString() == "GenerateCredentialReport") {
                console.log('Not sending slack message for ' + m_event.toString());
                return;
            }
            console.log('Sending slack message for ' + m_event.toString());
            
            var footer_text = 'Event time: '+m_time+'  User ARN:'+m_arn;
            
            var ttle = 'CloudWatch Event Rule Triggered for ' + m_event;

            var params = {                
                attachments: [{
                    fallback: text_msg,
                    pretext: rec.Sns.Subject,
                    color: "warning",
                    text: text_msg,
                    title: ttle,
                    footer: footer_text
                }]
            };
            req.write(JSON.stringify(params));

            req.end();
        }
    });
};